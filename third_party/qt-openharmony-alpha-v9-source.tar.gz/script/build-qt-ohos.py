import os
import sys
import io
import argparse
from build_qt.qt_repo import QtRepo, QtRepoError
from build_qt.qt5_build import Qt5Build
from build_qt.config import Config

def init_parser():
    parser = argparse.ArgumentParser(description='Build Qt for OHOS')
    parser.add_argument('--init', action='store_true', help='初始化Qt仓库,并应用补丁')
    parser.add_argument('--env_check', action='store_true', help='检查开发环境')
    parser.add_argument('--reset_repo', action='store_true', help='重置Qt仓库,并重新应用补丁')
    build_stages = ['configure', 'build', 'install', 'clean', 'all', "print_build_info"]
    parser.add_argument('--exe_stage', type=str, choices=build_stages, help='执行指定阶段')
    parser.add_argument("--with_pack", action="store_true", help="编译后是否打包编译结果")
    parser.add_argument('--use_github', action='store_true', help='使用GitHub地址')
    _args = parser.parse_args()
    if not any(vars(_args).values()):
        parser.print_help()
        exit(0)
    return _args

if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stdout.reconfigure(line_buffering=True)
    args = init_parser()
    
    # 获取配置文件路径
    # 优先使用当前目录的配置文件，如果不存在则使用包内的默认配置
    config_path = os.path.join(os.getcwd(), 'configure.json')
    if not os.path.exists(config_path):
        # 使用包内的默认配置文件
        package_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(package_dir, 'configure.json')
        if not os.path.exists(config_path):
            print(f'错误: 找不到配置文件 configure.json')
            print(f'已尝试: {os.path.join(os.getcwd(), "configure.json")}')
            print(f'已尝试: {config_path}')
            exit(1)

    config = Config(config_path, args.use_github)
    
    # 根据Qt版本选择目录名
    qt_dir_name = 'qt6' if config.is_qt6() else 'qt5'
    qt_dir = os.path.join(config.get_working_dir(), qt_dir_name)

    repo = QtRepo(qt_dir, config)
    if args.init:
        try:
            # Qt源码克隆
            repo.clone()

            # Qt OHOS补丁仓库克隆
            repo.clone_patch_repo()

            # Qt5在init阶段应用补丁，Qt6在build阶段应用
            if not config.is_qt6():
                print('Qt5：在init阶段应用补丁')
                repo.apply_patches()
            else:
                print('Qt6：补丁将在build阶段（主机编译后）应用')
        except QtRepoError as e:
            print('QtRepoError:', e)
            exit(1)
        except Exception as e:
            print('Error:', e)
            exit(1)
        exit()
    if args.reset_repo:
        try:
            # 重新应用补丁
            repo.apply_patches()
        except QtRepoError as e:
            print('QtRepoError:', e)
            exit(1)
        except Exception as e:
            print('Error:', e)
            exit(1)
        exit()
    if args.exe_stage is not None or args.env_check:
        # 开发环境检查
        config.dev_env_check()
        if args.env_check:
            exit()
        
        # 根据Qt版本选择对应的构建类
        if config.is_qt6():
            from build_qt.qt6_build import Qt6Build
            print('检测到Qt6版本，使用Qt6Build类')
            qtBuild = Qt6Build(qt_dir, config)
        else:
            print('检测到Qt5版本，使用Qt5Build类')
            qtBuild = Qt5Build(qt_dir, config)
        
        # 配置
        if args.exe_stage == 'clean':
            qtBuild.clean()
            exit()
        if args.exe_stage == 'configure' or args.exe_stage == 'all':
            try:
                qtBuild.configure()
            except Exception as e:
                print('Error during configuration:', e)
                exit(1)
        # 构建
        if args.exe_stage == 'build' or args.exe_stage == 'all':
            try:
                qtBuild.build(config.build_jobs())
            except Exception as e:
                print('Error during build:', e)
                exit(1)
        # 安装
        if args.exe_stage == 'install' or args.exe_stage == 'all':
            try:
                qtBuild.install()
            except Exception as e:
                print('Error during install:', e)
                exit(1)
        # 打包
        if args.with_pack:
            try:
                qtBuild.pack()
            except Exception as e:
                print('Error during pack:', e)
                exit(1)

        if args.exe_stage == 'print_build_info':
            qtBuild.print_build_info()
    exit()

