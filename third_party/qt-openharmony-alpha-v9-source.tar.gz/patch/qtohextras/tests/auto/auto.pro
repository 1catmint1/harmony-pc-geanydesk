TEMPLATE = subdirs
SUBDIRS += \
        cmake 
