SOURCES = stltest.cpp
